package com.example.project2;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerItemAdapter extends RecyclerView.Adapter<RecyclerItemAdapter.ViewHolder> {

    Context context;
    ArrayList<ItemModel> arrItem;

    RecyclerItemAdapter(Context context, ArrayList<ItemModel> arrItem){
        this.context = context;
        this.arrItem = arrItem;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_row, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.imgItem.setImageResource(arrItem.get(position).img);
        ItemModel model = (ItemModel) arrItem.get(position);
        holder.txtName.setText(arrItem.get(position).product);
        holder.txtQuantity.setText(arrItem.get(position).quantity);
        holder.txtPrice.setText(arrItem.get(position).price);

        holder.llRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.activity_data_display);

                EditText edtProductName = dialog.findViewById(R.id.productName);
                EditText edtQuantity = dialog.findViewById(R.id.quantity);
                EditText edtPrice = dialog.findViewById(R.id.price);
                Button btnAction = dialog.findViewById(R.id.btnAction);
                TextView txtTitle = dialog.findViewById(R.id.txtTitle);

                txtTitle.setText("Update Item");

                //AddItem.setText("Update");

                edtProductName.setText((((ItemModel) arrItem.get(position)).product));
                edtQuantity.setText(((ItemModel) arrItem.get(position)).quantity);
                edtPrice.setText(((ItemModel) arrItem.get(position)).price);



                btnAction.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String product = "";
                        String price = "";
                        String quantity = "";

                        if (!edtProductName.getText().toString().equals("")) {
                            product = edtProductName.getText().toString();
                        } else {
                            Toast.makeText(context, "Please Enter Product Name", Toast.LENGTH_SHORT).show();
                        }
                        if (!edtQuantity.getText().toString().equals("")) {
                            quantity = edtQuantity.getText().toString();
                        } else {
                            Toast.makeText(context, "Please Enter Quantity", Toast.LENGTH_SHORT).show();
                        }
                        if (!edtPrice.getText().toString().equals("")) {
                            price = edtPrice.getText().toString();
                        } else {
                            Toast.makeText(context, "Please Enter Price", Toast.LENGTH_SHORT).show();
                        }

                        arrItem.set(position, new ItemModel(product, quantity, price));

                        notifyItemChanged(position);

                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

        //The delete method when a user presses and holds the item in recycler view
        holder.llRow.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Delete Item")
                        .setMessage("Are you sure you want to delete?")
                        .setIcon(R.drawable.ic_baseline_delete_24)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                arrItem.remove(position);
                                notifyItemRemoved(position);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                builder.show();

                return true;
            }
        });
    }

    @Override
    public int getItemCount() { return arrItem.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView txtName, txtQuantity, txtPrice;
        ImageView imgItem;
        LinearLayout llRow;

        public ViewHolder(@NonNull View itemView){
            super(itemView);

            txtName = itemView.findViewById(R.id.txtName);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            txtPrice = itemView.findViewById(R.id.txtPrice);
            imgItem = itemView.findViewById(R.id.imgItem);
            llRow = itemView.findViewById(R.id.llRow);

        }

    }

}
