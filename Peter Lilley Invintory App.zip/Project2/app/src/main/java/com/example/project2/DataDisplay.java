package com.example.project2;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class DataDisplay extends MainActivity {
    ArrayList<ItemModel> arritem = new ArrayList<>();
    RecyclerItemAdapter adapter;
    FloatingActionButton btnOpenDialog;
    RecyclerView recyclerView;
    Button btnAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        recyclerView = findViewById(R.id.recyclerItem);
        btnOpenDialog = findViewById(R.id.btnOpenDialog);
        btnAction =  findViewById(R.id.btnAction);

        //Action button to change the inventory
        btnOpenDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(DataDisplay.this);
                dialog.setContentView(R.layout.activity_data_display);

                EditText edtProductName = dialog.findViewById(R.id.productName);
                EditText edtQuantity = dialog.findViewById(R.id.quantity);
                EditText edtPrice = dialog.findViewById(R.id.price);
                Button btnAction = dialog.findViewById(R.id.btnAction);

                btnAction.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String product = "";
                        String price = "";
                        String quantity = "";
                        int img = 0;

                        if (!edtProductName.getText().toString().equals("")) {
                            product = edtProductName.getText().toString();
                        } else {
                            Toast.makeText(DataDisplay.this, "Please Enter Product Name", Toast.LENGTH_SHORT).show();
                        }
                        if (!edtQuantity.getText().toString().equals("")) {
                            quantity = edtQuantity.getText().toString();
                        } else {
                            Toast.makeText(DataDisplay.this, "Please Enter Quantity", Toast.LENGTH_SHORT).show();
                        }
                        if (!edtPrice.getText().toString().equals("")) {
                            price = edtPrice.getText().toString();
                        } else {
                            Toast.makeText(DataDisplay.this, "Please Enter Price", Toast.LENGTH_SHORT).show();
                        }
                        quantity = quantity + " total";
                        price = "$" + price + " each";

                        //Goes with SMS message cant get it to work
                        //int quantityInt = Integer.parseInt(quantity);

                        //if(quantityInt < 5){addNotification}

                        arritem.add(new ItemModel(img,product, quantity, price));

                        adapter.notifyItemInserted(arritem.size());

                        recyclerView.scrollToPosition(arritem.size());

                        dialog.dismiss();

                    }
                });

                dialog.show();

            }
            //To send a SMS message
            /* Cant get it to work properly
            private void addNotification() {
                // Builds your notification
                NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                        .setSmallIcon(R.mipmap.ic_launcher_round)
                        .setContentTitle("Inventory")
                        .setContentText("Your inventory on " + edtProductName + " is less than 5");

                // Creates the intent needed to show the notification
                Intent notificationIntent = new Intent(this, MainActivity.class);
                PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(contentIntent);

                // Add as notification
                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                manager.notify(0, builder.build());
            }
            */
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Preloaded inventory
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Mixer", "5 total", "$5 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Blender", "3 total", "$7 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Coffee Machine", "15 each", "$6 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Pots", "2 total", "$15 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Knife Block", "1 total", "$50 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Disk Rack", "5 total", "$1 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Toaster", "8 total", "$18 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Air Fryer", "6 total", "$52 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Sous Vide", "3 total", "$100 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Microwave", "12 total", "$85 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "Dishwasher", "11 total", "$500 each"));
        arritem.add(new ItemModel(R.drawable.ic_baseline_add_shopping_cart_24, "test", "8 total", "$250 each"));

       adapter = new RecyclerItemAdapter(this, arritem);

        recyclerView.setAdapter(adapter);
    }
}

