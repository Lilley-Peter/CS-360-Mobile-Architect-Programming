package com.example.project2;

public class ItemModel {
    String product, quantity, price;
    int img;

    public ItemModel(int image, String product, String quantity, String price){
        this.product = product;
        this.quantity = quantity;
        this.price = price;
        this.img = img;
    }

    public ItemModel(String product, String quantity, String price){
        this.product = product;
        this.quantity = quantity;
        this.price = price;
    }
    public ItemModel(String product, String quantity){
        this.product = product;
        this.quantity = quantity;
    }
}
